<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accademy_owner extends CI_Controller 
{
  	function __construct() 
  	{
        parent::__construct();
        $this->load->model('Accademy_owner_model');
    }
    public function index()
    {
      	if(!$_SESSION['acc_owner_id'])
      	{
      		redirect(base_url());
      	}
        $id=$_SESSION['acc_owner_id'];
        $data['academies']=$this->Accademy_owner_model->get_specific_academies($id);
      	$this->load->view('academy_owner_home', $data);
  	}
  	public function insert_academy()
  	{

    		$org_name=$_FILES['academy_logo']['name'];
    		$tmp_name=$_FILES['academy_logo']['tmp_name'];
    		$folder="Acadmies/Logo";
    		$dir=Upload_image($org_name,$tmp_name,$folder);
    		$data = $this->input->post();
    		$check=$this->Accademy_owner_model->add_new_academy($data,$dir);
      	if($check)
      	{
      			redirect(base_url().'accademy_owner/index');
      	}
    }
    public function get_all_academies()
    {
        if(!$_SESSION['acc_owner_id'])
        {
            redirect(base_url());
        }
        $data['academies']=$this->Accademy_owner_model->get_all_academies_data();
        $this->load->view('academy_owner_home', $data);
    }
}
?>