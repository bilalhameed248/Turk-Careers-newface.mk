<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feed extends CI_Controller 
{

	function __construct() {
        parent::__construct();
        $this->load->model('user');
        $this->load->model('jobs_offered');
        $this->load->model('Feed_model');
        $this->load->model('Settings_model');

        //$_SESSION['message'] = '';
    }
	
	public function index()
	{
		
		
		if(!$this->session->has_userdata('logged_in') && !$this->session->has_userdata('owner_logged_in'))
		{
			redirect(base_url().'home/login');
			exit();
		}
		//print_r($_SESSION);
        $activity="Visited News feed page";
		if(isset($_SESSION['logged_in'])){
			$this->Settings_model->add_activity($roleid=1,$_SESSION['user_id'],$activity);
		}
		elseif(isset($_SESSION['owner_logged_in'])){
			$this->Settings_model->add_activity($roleid=2,$_SESSION['owner_logged_in'],$activity);
		} 
		
		
		$data['news_feed']=$this->Feed_model->get_news_feed();
		//print_r($data['news_feed']);
		
        if (isset($_SESSION['logged_in'])) {
			$user_id=$this->session->userdata('user_id');
			$data['user_details']=$this->user->get($user_id,FALSE,1);
            $skills=$data['user_details']->skills;
			
			$data['jobs']=$this->jobs_offered->get($skills);
        }
		elseif(isset($_SESSION['owner_logged_in']))
		{
			
			$user_id=$this->session->userdata('owner_id');
			$data['user_details']=$this->user->get($user_id,FALSE,2);
		}
		
		$this->load->view('timeline/feed3',$data);

	}
	function timeline($user_type,$user_id)
	{
        $data['news_feed']=$this->Feed_model->get_news_feed($user_type,$user_id);
		$data['user_info']=$this->user->get($user_id,FALSE,$user_type);
		$data['user_type']=$user_type;
		print_r($data['user_info']);
		$this->load->view('timeline/timeline',$data);
	}
	public function post_comment()
	{
		$array = array(
        'comment_desc' => $_POST['comment_desc'],
        'post_id' => $_POST['post_id'],
        'comment_by'   => $_SESSION['user_id']
		);
		if($this->db->insert('comments', $array))
		{
			echo 1;
		}
	}	
	public function add_new_post()
	{
		if(isset($_SESSION['logged_in'])){
			$type=1;
			$user_id=$_SESSION['user_id'];
		}
		elseif(isset($_SESSION['owner_logged_in'])){
			$type=2;
			$user_id=$_SESSION['owner_id'];
		}
	    $images=$_FILES['post_images'];

		$data = array(
        'description' => $_POST['post_desc'],
        'news_feed_user_id'   => $user_id,
		'user_type'=>$type
		);

        $post_id=$this->Feed_model->insert_post( $data);
		if($post_id!=0)
		{
            $this->Feed_model->insert_post_images($post_id,$images);
            redirect(base_url().'feed');
		}
	}	
}
