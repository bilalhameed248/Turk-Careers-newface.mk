<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('user');
        $this->load->model('Accademy_owner_model');
        $this->load->model('jobs_offered');
		$this->load->model('Subscriptions_model');
		$this->load->model('Settings_model');

        $_SESSION['message'] = '';
    }
	
	public function index()
	{
		if(isset($_SESSION['logged_in'])||isset($_SESSION['owner_logged_in'])){
			redirect(base_url().'feed');
		}
		

		$this->load->view('index');
	}
	public function login()
	{
		if(isset($_POST['submit']))
		{
			$array_items = array('owner_email', 'owner_id','owner_name','owner_logged_in');

			$this->session->unset_userdata($array_items);
			$islogedin=$this->user->checklogin($_POST);
			if($islogedin)
			{
				redirect(base_url().'feed');
			}
			else
			{

				$this->session->set_flashdata('message_detail', 'Invalid Credintial');
				redirect(base_url().'home/login');
			}
		}
		else
		{

			$this->load->view('signin');
		}
	}
	public function forgetpass()
    {
        if(!isset($_POST['submit'])){
            $this->load->view('forgetpass');
        } else{
            $email=$this->input->post('email');
            $isreg=$this->user->is_email_reg($email);
            if(!$isreg)
            {
                $this->session->set_flashdata('message_detail', 'This email is not registered');
                redirect(base_url().'home/forgetpass');

            } else{
            $newpass=generate_random_string(6);
            $data=array('password'=>$newpass);
            $this->user->update_by_email($data,$email);
            $send=send_pass_email($newpass,$email);
            if($send){
                $this->session->set_flashdata('message_detail', 'New password has been sent to your mail');
                redirect(base_url().'home/login');
                 }
            }
        }
    }
	function filter_acc()
  {

      // $loc=$this->input->post('loc');
      $title=$this->input->post('title');
      
      $allaccs=$this->Accademy_owner_model->get_all_academies_data($title);
      $result='';
        foreach($allaccs as $acc)
        {
          $result.='<div class="central-meta item">    
            <div class="user-post job">
              <div class="friend-info">
                <figure>
                  <img src="'.base_url().$acc["academy_logo"].'" alt="">
                </figure>
                <div class="friend-name">
                  <div class="more">
                    <div class="more-post-optns"><i class="ti-more-alt"></i>
                      
                    </div>
                  </div>
                  <ins><a href="#" title="">'.$acc["acc_owner_name"].'</a> Registered an Academy</ins>
                  <!-- <em class="verify"><i class="fa fa-check-circle"></i> verified</em> -->
                  <span><i class="fa fa-clock-o"></i> Jan,5 2020</span>
                </div>
                <ol class="pit-rate">
                  <li class="rated"><i class="fa fa-star"></i></li>
                  <li class="rated"><i class="fa fa-star"></i></li>
                  <li class="rated"><i class="fa fa-star"></i></li>
                  <li class="rated"><i class="fa fa-star"></i></li>
                  <li class=""><i class="fa fa-star"></i></li>
                </ol>
                <div class="post-meta">
                  <h3><a href="#" title="">'.$acc["academy_name"].'</a></h3>
                  <div class="loc-cate">
                    
                    <!-- <ul class="loc">
                      <li>Php Developer</li>
                      <li><span>$4k+</span> Spent</li>
                      <li><i class="fa fa-map-marker"></i> London</li>
                    </ul> -->
                  </div>
                  <div class="description">
                    <p>'.
                       substr($acc["academy_desc"],0,100).'
                    </p>
                  </div>
                  <div class="rate-n-apply">
                    <div class="job-price">
                      <span>Owner Email :</span>
                      <ins>'.$acc["acc_email"].'</ins>
                    </div>
                    <br>
                    <a href="'.$acc["academy_website_url"].'" target="_blank" style="float: right;"><button class="btn btn-primary">Details</button></a>
                  </div>
   
                </div>
          
              </div>
            </div>
          </div>';
       } 
      print_r($result);
  }
	public function accsignup()
	{
		if(!isset($_POST['submit']))
		{
			$this->load->view('accsignup');
		}
		else
		{
			
			$data=$this->input->post();
			$email=$data['owner_email'];
			$isreg=$this->Accademy_owner_model->is_email_reg($email);
			if(!$isreg)
			{
				$this->Accademy_owner_model->register($data,$dir);
				$this->session->set_flashdata('message_detail', 'Password has been sent to your email');
				redirect(base_url().'home/acc_owner_login');
			}
			else
			{
				$this->session->set_flashdata('message', 'email_reg');
				$this->load->view('accsignup');
			}
		}
	}
	public function list_academies()
	{
		if(!$this->session->has_userdata('logged_in')&&!$this->session->has_userdata('owner_logged_in'))
	    {

	      $this->load->view('signin');
	      exit();
	    }
	    $user_id=$this->session->userdata('user_id');
	      $data['user_data']=$this->user->get($user_id);
	      $skills=$data['user_data']->skills;
	      $data['jobs']=$this->jobs_offered->get($skills); //fetching jobs of interests
		$this->load->view('acclistings',$data);
	}
	public function acc_owner_login()
	{
		if(isset($_POST['submit']))
		{
			$islogedin=$this->Accademy_owner_model->accademy_owner_login($_POST);
			if($islogedin)
			{
				redirect(base_url().'accademy_owner/index');
			}
			else
			{
				$this->session->set_flashdata('message_detail', 'Invalid Credintial');
				redirect(base_url().'home/acc_owner_login');
			}
		}
		else
		{
			$this->load->view('accsignin');
		}
	}
	public function acc_owner_logout()
	{
		$logout=$this->user->logout();
		if($logout)
		{
			redirect(base_url());
		}
		
	}
	
	function subscription()
	{
        if(!$this->session->has_userdata('logged_in')&&!$this->session->has_userdata('owner_logged_in'))
        {

            $this->load->view('signin');
            exit();
        }
		
		if(isset($_SESSION['logged_in'])){
			$roleid=1;
			$userr_id=$_SESSION['user_id'];
		}
		elseif(isset($_SESSION['owner_logged_in'])){
			$roleid=2;
			$userr_id=$_SESSION['owner_id'];
		}
        $activity="Viewed Subscription page";
        $this->Settings_model->add_activity($roleid=$roleid,$userr_id,$activity);
		
		$data['user']=$this->user->get($userr_id);
		
		$data['subscriptions']=$this->Subscriptions_model->get();
		$this->load->view('subscription',$data);
	}
	function callback()
    {
        print_r($_SESSION);
    }
    function failurl()
    {

    }
	function testpayment()
    {
        $this->load->view('test_bankapi');
    }
	public function esignin()
	{
		if(isset($_POST['submit']))
		{
			$islogedin=$this->user->employer_login($_POST);
			if($islogedin)
			{
				redirect(base_url().'jobs/list');
			}
			else
			{
				$this->session->set_flashdata('message_detail', 'Invalid Credintial');
				redirect(base_url().'home/esignin');
			}
		}
		else
		{
			$this->load->view('esignin');
		}
	}
	public function esignup()
	{
		if(isset($_POST['submit']))
		{
			$data=$this->input->post();
			$email=$data['owner_email'];
			$isreg=$this->user->is_email_reg_employee($email);
			if($isreg)
			{
				$this->session->set_flashdata('message_detail', 'Email Already Registered...');
				redirect(base_url().'home/esignin');
			}
			$org_name=$_FILES['company_logo']['name'];
			$tmp_name=$_FILES['company_logo']['tmp_name'];
			$folder="companies_logo";
			$dir=Upload_image($org_name,$tmp_name,$folder);
			$lastid=$this->user->insertemployer($this->input->post(),$dir);
            $activity="Just registered himeself";
            $this->Settings_model->add_activity($roleid=2,$lastid,$activity);
			$this->session->set_flashdata('message_detail', 'Password has been sent to your email');
			redirect(base_url().'home/esignin');
		}
		else
		{
			$this->load->view('esignup');
		}
	}
	public function signup()
	{
		if(isset($_POST['submit']))
		{
			$data=$this->input->post();
			$email=$data['email'];
			$isreg=$this->user->is_email_reg($email); //isemail already registered.... '1' tells to get id of that email
			if(!$isreg)
			{
				$userid=$this->user->register($data,$dir);
                $activity="Just registered himself";
                $this->Settings_model->add_activity($roleid=1,$userid,$activity);
				$this->session->set_flashdata('message_detail', 'Password has been sent to your email');
				redirect(base_url().'home/login');
			}
			else
			{
				
				$this->session->set_flashdata('message_detail', 'Email Already Registered...');
				$this->load->view('signup');
			}
			
		}
		else
		{
			$_SESSION['message'] = '';

			$this->load->view('signup');
		}
		
	}
	public function logout()
	{
		$logout=$this->user->logout();
		if($logout)
		{
			redirect(base_url());
		}
	}
	public function dash()
	{
		if($this->session->has_userdata('logged_in'))
		{
			$this->load->view('admin/index');
		}
		else
		{
			redirect(base_url().'home/login');
		}
		
	}
	public function profile($id='')
	{
		if($this->session->has_userdata('logged_in'))
		{
			if(!isset($_POST['submit']))
			{
				$id=$_SESSION['user_id'];
				//echo $id;
				$data['user']=$this->user->get($id);
				$data['institutes']=$this->user->user_institutes($id,FALSE);// false means No count
				$data['num_institutes']=$this->user->user_institutes($id,TRUE);// True means  count
				$rec=$this->user->getkills(TRUE,$id);//True means count
				if($rec>0)
				{
					$data['skill_exist']=TRUE;
				}
				else
				{
					$data['skill_exist']=FALSE;
				}
				$this->load->view('setting',$data);
			}
			else
			{
				//echo "hhhh";
				$id=$_SESSION['user_id'];
				$profile=$this->input->post();
				//print_r($profile);
				$data=array(
					'fname' =>$profile['fname'],
					'lname' =>$profile['lname'],
					'email' =>$profile['email'],
					'phone_number' =>$profile['phone_number'],
					'skills' =>$profile['skills'],
					'about' =>$profile['about']
				);
				if($data['skills']=='')
				{
					$data['skills']=NULL;
				}
				$this->user->update_profile($data,$id);
				$i=0;
				//print_r($profile['institute_name']);
				foreach($profile['institute_name'] as $ins)
				{
					$inst=array(
						'id'=>$profile['inpid'][$i],
						'institute_name'=>$ins,
						'from_date' =>$profile['institute_fromdate'][$i],
						'to_date' =>$profile['institute_enddate'][$i]
					);

					if($inst['id']==0)
					{
						echo "data insert <br>";
						$this->user->add_institutes($inst,$id);
					}
					else
					{
						echo "data update <br>";
						$update=$this->user->update_institutes($inst,$id); // will update institute on basis of name and userid
					}
					$i++;
				}
				//exit();
                $activity="Updated profile";
                $this->Settings_model->add_activity($roleid=1,$_SESSION['user_id'],$activity);
				redirect(base_url().'home/profile');
			}
		}
		else
		{
			redirect(base_url().'home/login');
		}
		
	}
	public function updatedp()
	{
        $activity="Updated profile picture";
        $this->Settings_model->add_activity($roleid=1,$_SESSION['user_id'],$activity);
		$id=$_SESSION['user_id'];
		$file=$_FILES['dpimage'];
		$dir=Upload_image($file['name'],$file['tmp_name'],'userdps');
		$info=array(
			'profile_pic' =>$dir
		);
		$this->user->update_profile($info,$id);
		redirect(base_url().'home/profile');
		
	}
	public function upload_profile()
	{
		$data=$_POST;
		$array = array(
        'fname' => $_POST['fname'],
        'lname' => $_POST['lname'],
        'email' => $_POST['email'],
        'phone_number' => $_POST['phone_number'],
        'skills' => $_POST['skills'],
        'experience' => $_POST['experience'],
        'companies_name' => $_POST['companies_name']
        
		);
		$this->db->where('id',$_SESSION['user_id']);
		$this->db->update('users', $array);
		$query = $this->db->get_where('degrees', array('user_id' => $_SESSION['user_id']));
		$count=$query->num_rows();
		if($count>0)
		{
			$array = array(
	        'title' => $_POST['degrees'],
	        'institute' => $_POST['institute'],
	        'percentage' => $_POST['percentage']

			);

			$this->db->where('user_id',$_SESSION['user_id']);
        	if($this->db->update('degrees', $array))
        	{
        		echo 1;
        	}
		}
		else
		{
			$array = array(
		        'title' => $_POST['degrees'],
		        'institute' => $_POST['institute'],
		        'percentage' => $_POST['percentage']

				);

			if($this->db->insert('degrees', $array))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		
	}
	public function main()
	{
		$this->load->view('timeline/timeline.php');
	}
	public function cvupload()
	{
		
		$orgname=$_FILES['cvfile']['name'];
		$tmp_name=$_FILES['cvfile']['tmp_name'];
		$folder='portfolios';
		$dir=Upload_image($orgname,$tmp_name,$folder); //function for file upload
		$data=cvparse($dir);

		$data=json_decode($data);
		if($data->message=="You have exceeded your daily/monthly API rate limit. Please review and upgrade your subscription plan at https://promptapi.com/subscriptions to continue.")
		{
			$this->session->set_flashdata('message_detail', 'API key for resume parser limit exceeded contact your developer and purchase new Subscription plan');
			redirect(base_url().'home/login');
			exit();
		}
		
		
		$name=explode(" ",$data->name);
		$fname=$name[0];
		$lname=$name[1];
		$email=$data->email;
		if($fname==''&&$email=='')
		{
			$this->session->set_flashdata('message_detail', 'Unknown data <ul><li>Either its not a real CV</li><li>Or format not supported</li><li>Or language may be other than English</li>');
			redirect(base_url().'home/login');
			exit();
		}
		$phone=$data->phone;
		$isreg=$this->user->is_email_reg($email);
		if($isreg)
		{
			$this->session->set_flashdata('message_detail', 'Email Already Registered...!');
			redirect(base_url().'home/login');
			
		}

		$cv_path=$dir;
		$skills=$data->skills;
		$skills=implode(",",$skills);
		$education=$data->education;
		$experience=$data->experience;
		$pass=generate_random_string(6);
		$info=array(

			'fname' =>$fname,
			'lname' =>$lname,
			'email' =>$email,
			'phone_number'=>$phone,
			'skills' =>$skills,
			'password'=>$pass,
			'cv_path' =>$cv_path
		);
		
		$insert_id=$this->user->insert_from_cv($info);
		if($insert_id!=0)
		{
			$this->user->addinstitutes($education,$insert_id);
			$sent=send_pass_email($pass,$email);
			if($sent)
			{
				$this->session->set_flashdata('message_detail', 'password has been sent to your mail');
			redirect(base_url().'home/login');
				//echo "sent";
			}
			//echo "inserted";
		}
	}
	public function view_all_academies()
	{
		$this->load->view('view_all_academies_home.php');
	}
	public function payment()
	{

		
		$this->load->view('payment');


		
		
		
		
		
	}

}
