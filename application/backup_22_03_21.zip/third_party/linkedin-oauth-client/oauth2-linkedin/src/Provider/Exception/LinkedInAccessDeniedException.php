<?php

namespace League\OAuth2\Client\Provider\Exception;

class LinkedInAccessDeniedException extends IdentityProviderException
{

}
