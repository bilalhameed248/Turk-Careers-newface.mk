<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paypall extends CI_model {

	function return_url()
	{
		echo "hello";
	}


}


?>