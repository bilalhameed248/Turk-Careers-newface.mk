<script src="<?php echo base_url();?>public/timeline2/js/main.min.js"></script>
	<script src="<?php echo base_url();?>public/timeline2/js/jquery-stories.js"></script>
	<script src="<?php echo base_url();?>public/timeline2/js/toast-notificatons.js"></script>
	<script src="../../../cdnjs.cloudflare.com/ajax/libs/gsap/1.18.2/TweenMax.min.js"></script><!-- For timeline slide show -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8c55_YHLvDHGACkQscgbGLtLRdxBDCfI"></script><!-- for location picker map -->
	<script src="<?php echo base_url();?>public/timeline2/js/locationpicker.jquery.js"></script><!-- for loaction picker map -->
	<script src="<?php echo base_url();?>public/timeline2/js/map-init.js"></script><!-- map initilasition -->
	<script src="<?php echo base_url();?>public/timeline2/js/page-tourintro.js"></script>
	<!-- <script src="<?php echo base_url();?>public/timeline2/js/page-tour-init.js"></script> -->
	<script src="<?php echo base_url();?>public/timeline2/js/script.js"></script>
	

</body>	

<!-- Mirrored from wpkixx.com/html/Job portal/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 13 Jan 2021 12:18:29 GMT -->
</html>