<!-- Footer Start -->
    <footer class="bg-dark elegant-color mt-4 mb-4 pb-3 pt-3">
      <div class="container-fluid w-75 border-bottom border-light">
        <div class="row mb-3">
          <div class="col">
            <h5 class="text-white">Jobs by Functional Area</h5>
            <ul class="list-group list-group-flush footer-links">
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
            </ul>
          </div>
          <div class="col">
            <h5 class="text-white">Jobs By City</h5>
            <ul class="list-group list-group-flush footer-links">
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
            </ul>
          </div>
          <div class="col">
            <h5 class="text-white">Jobs By Industry</h5>
            <ul class="list-group list-group-flush footer-links">
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
            </ul>
          </div>
          <div class="col">
            <h5 class="text-white">Job Seekers</h5>
            <ul class="list-group list-group-flush footer-links">
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
            </ul>
          </div>
          <div class="col">
            <h5 class="text-white">International Jobs</h5>
            <ul class="list-group list-group-flush footer-links">
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              <li class="list-group"><a href="#" class="text-white">Creative Design Jobs </a></li>
              
            </ul>
            <h5 class="text-white pt-3">Follow Us</h5>
            <div class="social-icon d-flex">
              <i class="fab fa-facebook text-white social-icon"></i>
              <i class="fab fa-linkedin-in text-white social-icon"></i>
              <i class="fab fa-youtube text-white social-icon"></i>
              <i class="fab fa-twitter text-white social-icon"></i>
              
            </div>
              

          </div>
      </div>
      </div>
    </footer>

    <!-- Footer End -->
         
    
  <!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="<?php echo base_url();?>public/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo base_url();?>public/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>public/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo base_url();?>public/js/mdb.min.js"></script>
  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.js"></script>
  <!-- Your custom scripts (optional) -->
  <script src="<?php echo base_url();?>public/js/theme.js"></script>

</body>
</html>